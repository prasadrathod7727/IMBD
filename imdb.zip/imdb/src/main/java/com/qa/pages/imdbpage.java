package com.qa.pages;



import com.qa.base.TestBase;



public class imdbpage extends TestBase{
	




}
